import type { SolutionData } from "./types";

function $(id: string): HTMLElement {
  return document.getElementById(id)!;
}

function buildPathPreview(solution: SolutionData): string {
  const slug = solution.problemSlug;
  const base = `${solution.language}/${solution.category}/${solution.difficulty.toLowerCase()}/${slug}/`;
  return `<span>${base}</span>solution.${solution.fileExtension}<br><span>${base}</span>README.md`;
}

function renderSolution(solution: SolutionData) {
  $("empty-state").style.display = "none";
  $("solution-state").style.display = "block";

  $("problem-title").textContent = `#${solution.problemNumber}. ${solution.problemTitle}`;

  const diffBadge = $("difficulty-badge");
  diffBadge.textContent = solution.difficulty;
  diffBadge.className = `badge badge-${solution.difficulty.toLowerCase()}`;

  $("lang-badge").textContent = solution.language;
  $("category-badge").textContent = solution.category;

  // Runtime
  if (solution.runtimePercentile !== null) {
    $("runtime-pct").textContent = `${solution.runtimePercentile.toFixed(1)}%`;
    $("runtime-pct").classList.remove("na");
  } else {
    $("runtime-pct").textContent = "N/A";
    $("runtime-pct").classList.add("na");
  }
  $("runtime-val").textContent = solution.runtimeValue || "";

  // Memory
  if (solution.memoryPercentile !== null) {
    $("memory-pct").textContent = `${solution.memoryPercentile.toFixed(1)}%`;
    $("memory-pct").classList.remove("na");
  } else {
    $("memory-pct").textContent = "N/A";
    $("memory-pct").classList.add("na");
  }
  $("memory-val").textContent = solution.memoryValue || "";

  $("path-preview").innerHTML = buildPathPreview(solution);
}

function showStatus(msg: string, type: "success" | "error") {
  const el = $("status");
  el.textContent = msg;
  el.className = type;
  el.style.display = "block";
}

function setLoading(loading: boolean) {
  const btn = $("push-btn") as HTMLButtonElement;
  const spinner = $("spinner") as HTMLElement;
  const label = $("push-label");
  btn.disabled = loading;
  spinner.style.display = loading ? "block" : "none";
  label.textContent = loading ? "Pushing..." : "Push to GitHub";
}

async function init() {
  const response = await chrome.runtime.sendMessage({ type: "GET_PENDING_SOLUTION" });
  if (!response.success || !response.data) return;

  const solution: SolutionData = response.data;
  renderSolution(solution);

  $("push-btn").addEventListener("click", async () => {
    setLoading(true);
    $("status").style.display = "none";

    const res = await chrome.runtime.sendMessage({
      type: "PUSH_TO_GITHUB",
      data: solution,
    });

    setLoading(false);

    if (res.success) {
      showStatus("✓ Pushed to GitHub successfully!", "success");
      $("push-btn").style.display = "none";
      $("discard-btn").textContent = "Close";
    } else {
      showStatus(`Error: ${res.error}`, "error");
    }
  });

  $("discard-btn").addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "CLEAR_PENDING" });
    window.close();
  });
}

$("open-options").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

init();
