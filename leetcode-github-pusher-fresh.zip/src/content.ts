import type { SolutionData } from "./types";

const LANGUAGE_MAP: Record<string, { name: string; ext: string }> = {
  golang: { name: "golang", ext: "go" },
  python3: { name: "python", ext: "py" },
  python: { name: "python", ext: "py" },
  javascript: { name: "javascript", ext: "js" },
  typescript: { name: "typescript", ext: "ts" },
  java: { name: "java", ext: "java" },
  cpp: { name: "cpp", ext: "cpp" },
  c: { name: "c", ext: "c" },
  rust: { name: "rust", ext: "rs" },
  kotlin: { name: "kotlin", ext: "kt" },
  swift: { name: "swift", ext: "swift" },
  ruby: { name: "ruby", ext: "rb" },
  scala: { name: "scala", ext: "scala" },
  csharp: { name: "csharp", ext: "cs" },
};

// LeetCode problem categories derived from tags
// We'll use the URL and DOM to infer category; fallback to "uncategorized"
const CATEGORY_KEYWORDS: Record<string, string[]> = {
  arrays: ["array", "matrix", "subarray"],
  "linked-lists": ["linked-list", "linked list"],
  "dynamic-programming": ["dynamic-programming", "dp", "memoization"],
  graphs: ["graph", "bfs", "dfs", "topological-sort"],
  trees: ["tree", "binary-tree", "binary-search-tree", "trie"],
  "hash-tables": ["hash-table", "hash-map"],
  "two-pointers": ["two-pointers", "sliding-window"],
  backtracking: ["backtracking", "recursion"],
  sorting: ["sorting", "sort"],
  "binary-search": ["binary-search"],
  strings: ["string"],
  math: ["math", "number-theory"],
  heaps: ["heap", "priority-queue"],
  greedy: ["greedy"],
  "stack-queue": ["stack", "queue", "monotonic-stack"],
};

function inferCategory(tags: string[]): string {
  const lowerTags = tags.map((t) => t.toLowerCase());
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    if (keywords.some((kw) => lowerTags.some((t) => t.includes(kw)))) {
      return category;
    }
  }
  return "uncategorized";
}

function getProblemSlug(): string {
  const match = window.location.pathname.match(/\/problems\/([^/]+)/);
  return match ? match[1] : "";
}

function extractPercentile(text: string): number | null {
  const match = text.match(/(\d+(?:\.\d+)?)\s*%/);
  return match ? parseFloat(match[1]) : null;
}

async function fetchProblemMeta(slug: string): Promise<{
  title: string;
  number: number;
  difficulty: "Easy" | "Medium" | "Hard";
  tags: string[];
} | null> {
  try {
    const res = await fetch("https://leetcode.com/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: `
          query getProblem($titleSlug: String!) {
            question(titleSlug: $titleSlug) {
              questionFrontendId
              title
              difficulty
              topicTags { slug }
            }
          }
        `,
        variables: { titleSlug: slug },
      }),
    });
    const json = await res.json();
    const q = json?.data?.question;
    if (!q) return null;
    return {
      title: q.title,
      number: parseInt(q.questionFrontendId),
      difficulty: q.difficulty as "Easy" | "Medium" | "Hard",
      tags: q.topicTags.map((t: { slug: string }) => t.slug),
    };
  } catch {
    return null;
  }
}

function scrapeAcceptedSubmission(): {
  code: string;
  language: string;
  runtimeText: string | null;
  memoryText: string | null;
} | null {
  // Look for the accepted submission result panel
  // LeetCode renders stats after submission in specific elements
  const resultEl = document.querySelector('[data-e2e-locator="submission-result"]');
  if (!resultEl || !resultEl.textContent?.toLowerCase().includes("accepted")) {
    return null;
  }

  // Get runtime and memory stats
  let runtimeText: string | null = null;
  let memoryText: string | null = null;

  const statItems = document.querySelectorAll(
    '.submission-result__performance, [class*="runtime"], [class*="memory"]'
  );

  // Try to find runtime/memory from the result page text
  document.querySelectorAll("*").forEach((el) => {
    const text = el.textContent || "";
    if (
      el.children.length === 0 &&
      text.includes("Beats") &&
      text.includes("%")
    ) {
      if (text.toLowerCase().includes("runtime") && !runtimeText) {
        runtimeText = text.trim();
      }
      if (text.toLowerCase().includes("memory") && !memoryText) {
        memoryText = text.trim();
      }
    }
  });

  // Get the code from the editor
  const codeLines = document.querySelectorAll(".view-line");
  let code = "";
  if (codeLines.length > 0) {
    code = Array.from(codeLines)
      .map((line) => line.textContent || "")
      .join("\n");
  }

  // Fallback: try monaco editor model
  if (!code) {
    const editorEl = document.querySelector(".monaco-editor");
    if (editorEl) {
      code = (editorEl as HTMLElement).innerText || "";
    }
  }

  // Get language from the language selector
  const langEl = document.querySelector(
    '[data-e2e-locator="code-lang-button"], button[id*="lang"]'
  );
  const langText = langEl?.textContent?.trim().toLowerCase() || "golang";
  const langKey = Object.keys(LANGUAGE_MAP).find((k) =>
    langText.includes(k)
  ) || "golang";

  return {
    code,
    language: langKey,
    runtimeText,
    memoryText,
  };
}

// Watch for DOM changes that indicate a successful submission
function watchForAcceptedSubmission() {
  let lastNotified = "";

  const observer = new MutationObserver(async () => {
    const resultEl = document.querySelector(
      '[data-e2e-locator="submission-result"]'
    );
    if (!resultEl) return;

    const resultText = resultEl.textContent?.toLowerCase() || "";
    if (!resultText.includes("accepted")) return;

    // Debounce — don't notify twice for the same result render
    const key = resultText + window.location.href;
    if (key === lastNotified) return;
    lastNotified = key;

    // Give the page a moment to render stats
    await new Promise((r) => setTimeout(r, 1500));

    const slug = getProblemSlug();
    if (!slug) return;

    const [meta, submission] = await Promise.all([
      fetchProblemMeta(slug),
      Promise.resolve(scrapeAcceptedSubmission()),
    ]);

    if (!meta || !submission) return;

    const langInfo = LANGUAGE_MAP[submission.language] || {
      name: submission.language,
      ext: "txt",
    };

    const runtimePercentile = submission.runtimeText
      ? extractPercentile(submission.runtimeText)
      : null;
    const memoryPercentile = submission.memoryText
      ? extractPercentile(submission.memoryText)
      : null;

    // Parse actual runtime/memory values (e.g. "3 ms", "2.1 MB")
    const runtimeValue =
      submission.runtimeText?.match(/[\d.]+ m?s/i)?.[0] || null;
    const memoryValue =
      submission.memoryText?.match(/[\d.]+ MB/i)?.[0] || null;

    const solution: SolutionData = {
      problemTitle: meta.title,
      problemSlug: slug,
      problemNumber: meta.number,
      difficulty: meta.difficulty,
      category: inferCategory(meta.tags),
      language: langInfo.name,
      fileExtension: langInfo.ext,
      code: submission.code,
      runtimePercentile,
      memoryPercentile,
      runtimeValue,
      memoryValue,
      problemUrl: `https://leetcode.com/problems/${slug}/`,
      submittedAt: new Date().toISOString(),
    };

    chrome.runtime.sendMessage({ type: "SOLUTION_CAPTURED", data: solution });
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

watchForAcceptedSubmission();
