export interface SolutionData {
  problemTitle: string;
  problemSlug: string;
  problemNumber: number;
  difficulty: "Easy" | "Medium" | "Hard";
  category: string;
  language: string;
  fileExtension: string;
  code: string;
  runtimePercentile: number | null;
  memoryPercentile: number | null;
  runtimeValue: string | null;
  memoryValue: string | null;
  problemUrl: string;
  submittedAt: string;
}

export interface ExtensionSettings {
  githubToken: string;
  githubRepo: string; // e.g. "username/repo"
  githubBranch: string; // default: "main"
}

export type MessageType =
  | { type: "SOLUTION_CAPTURED"; data: SolutionData }
  | { type: "GET_PENDING_SOLUTION" }
  | { type: "PUSH_TO_GITHUB"; data: SolutionData }
  | { type: "CLEAR_PENDING" };

export type MessageResponse =
  | { success: true; data?: SolutionData }
  | { success: false; error: string };
