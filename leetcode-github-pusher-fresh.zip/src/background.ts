import type { SolutionData, ExtensionSettings } from "./types";

// Store the latest captured solution
let pendingSolution: SolutionData | null = null;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "SOLUTION_CAPTURED") {
    pendingSolution = message.data;
    // Show badge to alert user
    chrome.action.setBadgeText({ text: "1" });
    chrome.action.setBadgeBackgroundColor({ color: "#00b8a3" });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === "GET_PENDING_SOLUTION") {
    sendResponse({ success: true, data: pendingSolution });
    return true;
  }

  if (message.type === "CLEAR_PENDING") {
    pendingSolution = null;
    chrome.action.setBadgeText({ text: "" });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === "PUSH_TO_GITHUB") {
    pushToGitHub(message.data)
      .then(() => sendResponse({ success: true }))
      .catch((err: Error) =>
        sendResponse({ success: false, error: err.message })
      );
    return true; // Keep channel open for async response
  }
});

async function getSettings(): Promise<ExtensionSettings> {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(
      ["githubToken", "githubRepo", "githubBranch"],
      (result) => {
        if (!result.githubToken || !result.githubRepo) {
          reject(new Error("GitHub settings not configured. Please open Options."));
          return;
        }
        resolve({
          githubToken: result.githubToken,
          githubRepo: result.githubRepo,
          githubBranch: result.githubBranch || "main",
        });
      }
    );
  });
}

function buildFilePath(solution: SolutionData, filename: string): string {
  // Structure: golang/arrays/easy/two-sum/solution.go
  return [
    solution.language,
    solution.category,
    solution.difficulty.toLowerCase(),
    solution.problemSlug,
    filename,
  ].join("/");
}

function buildReadme(solution: SolutionData): string {
  const stars =
    solution.difficulty === "Easy"
      ? "⭐"
      : solution.difficulty === "Medium"
      ? "⭐⭐"
      : "⭐⭐⭐";

  const runtime =
    solution.runtimeValue && solution.runtimePercentile !== null
      ? `${solution.runtimeValue} (beats ${solution.runtimePercentile.toFixed(1)}% of submissions)`
      : "N/A";

  const memory =
    solution.memoryValue && solution.memoryPercentile !== null
      ? `${solution.memoryValue} (beats ${solution.memoryPercentile.toFixed(1)}% of submissions)`
      : "N/A";

  return `# ${solution.problemNumber}. ${solution.problemTitle}

**Difficulty:** ${solution.difficulty} ${stars}  
**Category:** ${solution.category}  
**Language:** ${solution.language}  
**Problem:** [LeetCode #${solution.problemNumber}](${solution.problemUrl})  
**Solved:** ${new Date(solution.submittedAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })}

## Performance

| Metric  | Result |
|---------|--------|
| Runtime | ${runtime} |
| Memory  | ${memory} |

## Solution

\`\`\`${solution.language}
${solution.code}
\`\`\`
`;
}

async function githubRequest(
  settings: ExtensionSettings,
  path: string,
  method: string,
  body?: object
): Promise<Response> {
  const res = await fetch(`https://api.github.com/repos/${settings.githubRepo}/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${settings.githubToken}`,
      "Content-Type": "application/json",
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  return res;
}

async function getExistingFileSha(
  settings: ExtensionSettings,
  filePath: string
): Promise<string | null> {
  const res = await githubRequest(
    settings,
    `contents/${filePath}?ref=${settings.githubBranch}`,
    "GET"
  );
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`GitHub API error: ${res.status}`);
  const data = await res.json();
  return data.sha || null;
}

async function upsertFile(
  settings: ExtensionSettings,
  filePath: string,
  content: string,
  commitMessage: string
): Promise<void> {
  const sha = await getExistingFileSha(settings, filePath);
  const body: Record<string, string> = {
    message: commitMessage,
    content: btoa(unescape(encodeURIComponent(content))),
    branch: settings.githubBranch,
  };
  if (sha) body.sha = sha;

  const res = await githubRequest(settings, `contents/${filePath}`, "PUT", body);
  if (!res.ok) {
    const err = await res.json();
    throw new Error(`Failed to push ${filePath}: ${err.message}`);
  }
}

async function pushToGitHub(solution: SolutionData): Promise<void> {
  const settings = await getSettings();

  const solutionFile = `solution.${solution.fileExtension}`;
  const solutionPath = buildFilePath(solution, solutionFile);
  const readmePath = buildFilePath(solution, "README.md");
  const readmeContent = buildReadme(solution);

  const runtimeInfo =
    solution.runtimePercentile !== null
      ? ` | Runtime: beats ${solution.runtimePercentile.toFixed(1)}%`
      : "";
  const memoryInfo =
    solution.memoryPercentile !== null
      ? ` | Memory: beats ${solution.memoryPercentile.toFixed(1)}%`
      : "";

  const commitMessage = `Solve #${solution.problemNumber}: ${solution.problemTitle} (${solution.difficulty})${runtimeInfo}${memoryInfo}`;

  await Promise.all([
    upsertFile(settings, solutionPath, solution.code, commitMessage),
    upsertFile(settings, readmePath, readmeContent, commitMessage),
  ]);

  // Clear badge after successful push
  pendingSolution = null;
  chrome.action.setBadgeText({ text: "" });
}
